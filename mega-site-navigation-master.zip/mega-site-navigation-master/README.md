Mega-Site Navigation
=========

A responsive and easy to customize navigation for mega-sites, enriched by subtle CSS animations and support for devices with javascript disabled.

[Article on CodyHouse](http://codyhouse.co/gem/css-mega-site-navigation/)

[Demo](http://codyhouse.co/demo/mega-site-navigation/index.html)

Icons by [Dario Ferrando](https://www.behance.net/darioferrando) available for free download on [Freebiesbug](http://freebiesbug.com/psd-freebies/linea-line-icon-set-psd-ai-webfont/)
 
[Terms](http://codyhouse.co/terms/)
